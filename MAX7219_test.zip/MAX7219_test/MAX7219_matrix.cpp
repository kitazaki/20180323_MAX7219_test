// MAX7219_matrix.cpp

#include <string.h>
#include "MAX7219_matrix.h"

// グローバル変数
static uint8_t buf[8*MAXSCREENS]; // 表示用バッファ
static byte _din;              // DIN
static byte _clk;              // CLK
static byte _load;             // LOAD
static byte _screens;          // MAX7219カスケード接続数

//
// MAX7219 1バイトデータ送信
//  data : 送信データ
//  戻り値 なし
//
inline void MAX7219_write(uint8_t data) {
  shiftOut(_din, _clk, MSBFIRST, data);
}

//
// MAX7219 レジスタ設定
// カソード接続している全てのMAX7219に対して同じ設定を行う
//   reg  : レジスタ番号
//   data : 設定値
//  戻り値 なし
//
void setRegister(uint8_t reg, uint8_t data){
  digitalWrite(_load, LOW); // begin
  for(uint8_t i = 0; i < _screens; ++i) {
    MAX7219_write(reg);  // specify register
    MAX7219_write(data); // send data
  }
  digitalWrite(_load, HIGH);  // latch in data
  digitalWrite(_load, LOW); // end
}

//
// MAX7219 バッファアドレス取得
// 戻り値 ： 表示用バッファの先頭アドレスを返す
//
uint8_t* MAX7219_getBuffer() {
  return buf;  
}

//
// MAX7219の初期化
//  din    : BINピン番号
//  clk    : CLKピン番号
//  load   : LOADピン番号
//  screens: MAX7219カスケード接続数(1～)
//  brt    : 輝度(0～7) 
//  data   : 表示用バッファ (screen*8バイト)
void MAX7219_init(uint8_t din, uint8_t clk, uint8_t load, uint8_t screens, uint8_t brt) {
  _din = din;
  _clk = clk;
  _load = load;
  _screens = screens;
  
  pinMode(_din,  OUTPUT);
  pinMode(_load, OUTPUT);
  pinMode(_clk,  OUTPUT);

  setRegister(REG_SCANLIMIT,0x07);        // 表示行数の設定(0～7)：7:全行
  setRegister(REG_INTENSITY,brt);         // 輝度の設定(0～7)
  setRegister(REG_SHUTDOWN, MODE_NORMAL);    // シャットダウンモード：ノーマル
  setRegister(REG_DECODEMODE,DECODE_NOTUSE); // キャラクタ利用：使用しない
  setRegister(REG_DISPLAYTEST, TEST_NORMAL); // テストモード：無効

  MAX7219_clear();
}

// MAX7219 表示のクリア
void MAX7219_clear() {
  MAX7219_clearBuffer();
  MAX7219_update();
}

// バッファクリア
void MAX7219_clearBuffer() {
  memset(buf, 0, _screens * 8);
}

// MAX7219 全点データ送信
void MAX7219_update() {
  for (byte i=0; i < 8; i++) {
    digitalWrite(_load, LOW);    // 送信開始
    for (byte j=0; j < _screens; j++) {
      MAX7219_write(i+1);
      MAX7219_write(buf[j + (_screens * i)]);
    }
    digitalWrite(_load, HIGH);   // データラッチ
    digitalWrite(_load, LOW);    // 送信終了 
  } 
}
