// MAX7219_matrix.h

#ifndef __MAX7219_matrix_h__
#define __MAX7219_matrix_h__
#include <arduino.h>

#define MAXSCREENS 8          // 最大接続数

// MAX7219レジスタマップアドレス
#define REG_NOOP        0x00  // no-opレジスタ
#define REG_DECODEMODE  0x09  // デコードモードレジスタ
#define REG_INTENSITY   0x0A  // 輝度レジスタ
#define REG_SCANLIMIT   0x0B  // スキャン制御レジスタ
#define REG_SHUTDOWN    0x0C  // シャットダウンレジスタ
#define REG_DISPLAYTEST 0x0F  // ディスプレイテストレジスタ

#define  MODE_SHUTDOWN  0
#define  MODE_NORMAL    1
#define  TEST_NORMAL    0
#define  TEST_DISPLAY   1
#define  DECODE_USE     1
#define  DECODE_NOTUSE  0

void MAX7219_write(uint8_t data);
void setRegister(uint8_t reg, uint8_t data);
uint8_t* MAX7219_getBuffer() ;
void MAX7219_clear();
void MAX7219_clearBuffer();
void MAX7219_init(uint8_t din, uint8_t clk, uint8_t load, uint8_t screens, uint8_t brt);
void MAX7219_update();

#endif
