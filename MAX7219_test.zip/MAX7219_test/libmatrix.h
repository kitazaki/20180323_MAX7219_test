// libmatrix.h
// ビットマップ操作関数宣言
void setDotAt(uint8_t* bmp, uint16_t w, uint16_t h, int16_t x, int16_t y, uint8_t d);
void setBitmapAt(uint8_t *dstbmp, uint16_t dstw, uint16_t dsth, int16_t dstx, int16_t dsty,uint8_t *srcbmp, uint16_t srcw, uint16_t srch);
void scrollBitmap(uint8_t *bmp, uint16_t w, uint16_t h, uint8_t mode);
void revBitmap(uint8_t *bmp, uint16_t w, uint16_t h);
void clearBitmapAt(uint8_t* bmp, uint16_t w, uint16_t h, int16_t x, int16_t y, uint8_t cw, uint8_t ch);
uint8_t getdotBitmap(uint8_t *bmp, uint16_t w, uint16_t h, int16_t x, int16_t y);
void rotateBitmap(uint8_t *bmp, uint16_t w, uint16_t h, uint8_t mode) ;

